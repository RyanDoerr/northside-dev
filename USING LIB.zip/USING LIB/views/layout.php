<?php
	session_start();
?>
<!DOCTYPE html>
	<html>
		<head>
		<script src="jquery.js"></script>
		</head>
		<body>
			<header>
				HEADERHEADERHEADER
			</header>

			<?php require_once('routes.php'); ?>

			<footer>
				Copyright Codist Technologies 2016 FOOTOR FOOTOR FOOTR
			</footer>
		</body>
	</html>