
What type of order is this?
<?php
	OrdersController::drawRadioButtons();
?>