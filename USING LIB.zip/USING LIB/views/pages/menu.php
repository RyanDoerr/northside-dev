<?php
	MenusController::makeMenu(MenusController::$displayNames['Menu']);

	//MenusController::$displayNames['Menu']
?>
